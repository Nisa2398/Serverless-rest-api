const express=require('express')
const router=express.Router()
const employee=require('../services/employeeservice')
const { body, validationResult } = require('express-validator');
router.get('/employees',employee.getEmployees)
router.put('/employees',body('email').isEmail(),employee.postEmployees)
module.exports=router