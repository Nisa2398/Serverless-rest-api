const AWS = require('aws-sdk');
const USERS_TABLE = process.env.USERS_TABLE;

const IS_OFFLINE = process.env.IS_OFFLINE;
let dynamoDb;
if (IS_OFFLINE === 'true') {
  dynamoDb = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1',
    // endpoint: 'http://localhost:8000',
    accessKeyId: 'AKIAR2V2UDMM7AIOBWMG',  // needed if you don't have aws credentials at all in env
    secretAccessKey: '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'
  })
  // console.log(dynamoDb);
} else {
  dynamoDb = new AWS.DynamoDB.DocumentClient();
};

exports.getEmployees=(req,res,next)=>{
    try{
    const params = {
        TableName: USERS_TABLE,
        Key: {
          email: req.query.email,
        },
      }
    dynamoDb.get(params, (error, result) => {
    if (error) {
      res.status(400).json({ error: 'Could not get user' });
    }
    console.log(result)
    if (result) {
     
      res.status(200).json(result)
    } else {
      res.status(404).json({ error: "User not found" });
    }
  });
}
catch(err){
    res.status(404).json({ error: err });
  }  
}
exports.postEmployees=(req,res,next)=>{
  try{
    const params = {
      TableName: USERS_TABLE,
      Item: {
        email:req.body.email,
        name:req.body.name,
        position:req.body.position
      },
    }
  dynamoDb.put(params, (error, result) => {
  if (error) {
    console.log(error)
    return res.status(400).json({ error: 'Could not add employee' });
  }
  
  return res.status(201).json({ result});
  
});
}
catch(err){
  res.status(404).json({ error: err });
}  
}